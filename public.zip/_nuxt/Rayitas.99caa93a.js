import"./entry.da50f3a8.js";const r=""+new URL("Rayitas.5341d471.svg",import.meta.url).href;export{r as _};
